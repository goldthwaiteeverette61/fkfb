#!/bin/bash

git pull

./b_no_pull.sh