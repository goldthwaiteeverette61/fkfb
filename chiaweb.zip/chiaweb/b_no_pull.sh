#!/bin/bash

mvn package -DskipTests

docker stop chiaweb
docker rm chiaweb
docker rmi $(docker images | grep none | awk '{print $3}')

docker build -t chiaweb:v1 .
docker run --name chiaweb -d -p 8081:8081 --link mysql57:mysql57 chiaweb:v1