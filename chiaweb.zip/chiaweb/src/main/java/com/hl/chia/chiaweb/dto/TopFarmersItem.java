package com.hl.chia.chiaweb.dto;

import com.hl.chia.chiaweb.entity.TbTopFarmers;
import lombok.Data;

@Data
public class TopFarmersItem extends TbTopFarmers {

}
