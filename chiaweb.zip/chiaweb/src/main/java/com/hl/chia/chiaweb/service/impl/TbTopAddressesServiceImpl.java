package com.hl.chia.chiaweb.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hl.chia.chiaweb.entity.TbTopAddresses;
import com.hl.chia.chiaweb.mapper.TbTopAddressesMapper;
import com.hl.chia.chiaweb.service.ITbTopAddressesService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Service
public class TbTopAddressesServiceImpl extends ServiceImpl<TbTopAddressesMapper, TbTopAddresses> implements ITbTopAddressesService {

}
