package com.hl.chia.chiaweb.controller;

public class BaseController {
}
