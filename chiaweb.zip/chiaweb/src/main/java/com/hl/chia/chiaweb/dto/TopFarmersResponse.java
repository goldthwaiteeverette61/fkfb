package com.hl.chia.chiaweb.dto;

import lombok.Data;

import java.util.List;

@Data
public class TopFarmersResponse extends BaseDto {

    List<TopFarmersItem> topFarmers;
}
