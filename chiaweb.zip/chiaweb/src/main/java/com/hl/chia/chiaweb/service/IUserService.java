package com.hl.chia.chiaweb.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hl.chia.chiaweb.entity.User;

public interface IUserService extends IService<User> {

}
