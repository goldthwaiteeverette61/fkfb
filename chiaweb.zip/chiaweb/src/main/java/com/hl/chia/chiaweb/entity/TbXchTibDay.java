package com.hl.chia.chiaweb.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class TbXchTibDay extends BaseEntity {

    private LocalDateTime createTime;

    private String timestamp;

    private String data;

    private int d = 1;


}
