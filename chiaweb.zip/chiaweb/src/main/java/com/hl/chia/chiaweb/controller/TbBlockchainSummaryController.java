package com.hl.chia.chiaweb.controller;


import com.hl.chia.chiaweb.entity.TbBlockchainSummary;
import com.hl.chia.chiaweb.service.ITbBlockchainSummaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@RestController
@RequestMapping("/blockchain-summary")
public class TbBlockchainSummaryController extends BaseController {

    @Autowired
    ITbBlockchainSummaryService iTbBlockchainSummaryService;

    @GetMapping
    public ResponseEntity<TbBlockchainSummary> get(){
        List<TbBlockchainSummary> tbBlockchainSummaryList = iTbBlockchainSummaryService.list();
        if(tbBlockchainSummaryList.size() > 0){
            return ResponseEntity.ok(tbBlockchainSummaryList.get(0));
        }

        return ResponseEntity.ok(new TbBlockchainSummary());
    }
}
