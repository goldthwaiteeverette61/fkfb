package com.hl.chia.chiaweb.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class TbTopPools extends BaseEntity {

    private static final long serialVersionUID = 1L;

    private Date createTime;

    private Integer rank;

    private String blocksWon;

    private String poolPublicKey;

    private String estimatedSpaceOnline;

    private String v;

}
