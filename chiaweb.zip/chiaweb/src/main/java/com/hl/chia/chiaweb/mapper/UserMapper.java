package com.hl.chia.chiaweb.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hl.chia.chiaweb.entity.User;

public interface UserMapper extends BaseMapper<User> {

}