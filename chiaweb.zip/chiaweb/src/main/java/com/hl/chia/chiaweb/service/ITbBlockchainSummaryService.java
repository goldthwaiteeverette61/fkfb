package com.hl.chia.chiaweb.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hl.chia.chiaweb.entity.TbBlockchainSummary;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
public interface ITbBlockchainSummaryService extends IService<TbBlockchainSummary> {

}
