package com.hl.chia.chiaweb.controller;


import com.hl.chia.chiaweb.entity.TbTopFarmers;
import com.hl.chia.chiaweb.entity.TbTopPools;
import com.hl.chia.chiaweb.service.ITbTopFarmersService;
import com.hl.chia.chiaweb.service.ITbTopPoolsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@RestController
@RequestMapping("/top-pools")
public class TbTopPoolsController extends BaseController {
    @Autowired
    ITbTopPoolsService iTbTopPoolsService;

    @GetMapping("list")
    public ResponseEntity<List<TbTopPools>> list(){
        return ResponseEntity.ok(iTbTopPoolsService.list());
    }
}
