package com.hl.chia.chiaweb.dto;

import lombok.Data;

import java.util.List;

@Data
public class TopAddressResponse extends BaseDto {

    List<TopAddressItem> topAddresses;
}
