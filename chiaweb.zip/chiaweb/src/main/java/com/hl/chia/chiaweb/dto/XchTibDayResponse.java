package com.hl.chia.chiaweb.dto;

import lombok.Data;

import java.util.List;

@Data
public class XchTibDayResponse extends BaseDto {

    private String data;
    private String timestamp;
}
