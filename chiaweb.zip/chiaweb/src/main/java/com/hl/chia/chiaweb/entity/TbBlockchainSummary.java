package com.hl.chia.chiaweb.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class TbBlockchainSummary extends BaseEntity {

    private static final long serialVersionUID = 1L;

    private LocalDateTime createTime;

    private String netspace;

    private String uniqueCoins;

    private String supply;

    private String addressCount;

}
