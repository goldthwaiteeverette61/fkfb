package com.hl.chia.chiaweb.controller;


import com.hl.chia.chiaweb.entity.TbTopAddresses;
import com.hl.chia.chiaweb.entity.TbTopFarmers;
import com.hl.chia.chiaweb.service.ITbTopAddressesService;
import com.hl.chia.chiaweb.service.ITbTopFarmersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@RestController
@RequestMapping("/top-farmers")
public class TbTopFarmersController extends BaseController {
    @Autowired
    ITbTopFarmersService iTbTopFarmersService;

    @GetMapping("list")
    public ResponseEntity<List<TbTopFarmers>> list(){
        return ResponseEntity.ok(iTbTopFarmersService.list());
    }
}
