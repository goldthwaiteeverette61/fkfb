package com.hl.chia.chiaweb.dto;

import com.hl.chia.chiaweb.entity.TbTopPools;
import lombok.Data;

@Data
public class TopPoolsItem extends TbTopPools {
    
}
