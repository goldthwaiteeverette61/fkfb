package com.hl.chia.chiaweb.controller;


import com.hl.chia.chiaweb.entity.TbTibHoursXch;
import com.hl.chia.chiaweb.service.ITbTibHoursXchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@RestController
@RequestMapping("/tib-hours-xch")
public class TbTibHoursXchController extends BaseController {

    @Autowired
    ITbTibHoursXchService iTbTibHoursXchService;

    @GetMapping
    public ResponseEntity<TbTibHoursXch> get(){

        List<TbTibHoursXch> tbTibHoursXchList = iTbTibHoursXchService.list();
        if(tbTibHoursXchList.size() > 0){
            return ResponseEntity.ok(tbTibHoursXchList.get(0));
        }

        return ResponseEntity.ok(new TbTibHoursXch());
    }
}
