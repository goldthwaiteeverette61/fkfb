package com.hl.chia.chiaweb.dto;

import com.hl.chia.chiaweb.entity.TbTopAddresses;
import lombok.Data;

@Data
public class TopAddressItem extends TbTopAddresses {

}
