package com.hl.chia.chiaweb.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hl.chia.chiaweb.entity.TbXchTibDay;
import com.hl.chia.chiaweb.entity.User;
import com.hl.chia.chiaweb.mapper.TbXchTibDayMapper;
import com.hl.chia.chiaweb.mapper.UserMapper;
import com.hl.chia.chiaweb.service.ITbXchTibDayService;
import com.hl.chia.chiaweb.service.IUserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

}