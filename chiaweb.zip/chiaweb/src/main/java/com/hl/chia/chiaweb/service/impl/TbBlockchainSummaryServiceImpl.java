package com.hl.chia.chiaweb.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hl.chia.chiaweb.entity.TbBlockchainSummary;
import com.hl.chia.chiaweb.mapper.TbBlockchainSummaryMapper;
import com.hl.chia.chiaweb.service.ITbBlockchainSummaryService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Service
public class TbBlockchainSummaryServiceImpl extends ServiceImpl<TbBlockchainSummaryMapper, TbBlockchainSummary> implements ITbBlockchainSummaryService {

}
