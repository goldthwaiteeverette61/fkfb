package com.hl.chia.chiaweb.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hl.chia.chiaweb.entity.TbTopAddresses;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
public interface ITbTopAddressesService extends IService<TbTopAddresses> {

}
