package com.hl.chia.chiaweb.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hl.chia.chiaweb.entity.TbTibHoursXch;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
public interface TbTibHoursXchMapper extends BaseMapper<TbTibHoursXch> {

}
