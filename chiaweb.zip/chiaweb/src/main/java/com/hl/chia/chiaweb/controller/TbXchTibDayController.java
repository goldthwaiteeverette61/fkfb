package com.hl.chia.chiaweb.controller;


import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.hl.chia.chiaweb.dto.HttpResponseObj;
import com.hl.chia.chiaweb.dto.TopFarmersResponse;
import com.hl.chia.chiaweb.dto.XchTibDayResponse;
import com.hl.chia.chiaweb.entity.TbTibHoursXch;
import com.hl.chia.chiaweb.entity.TbTopFarmers;
import com.hl.chia.chiaweb.entity.TbTopPools;
import com.hl.chia.chiaweb.entity.TbXchTibDay;
import com.hl.chia.chiaweb.service.ITbTibHoursXchService;
import com.hl.chia.chiaweb.service.ITbTopFarmersService;
import com.hl.chia.chiaweb.service.ITbTopPoolsService;
import com.hl.chia.chiaweb.service.ITbXchTibDayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@RestController
@RequestMapping("/xch-tib-day")
public class TbXchTibDayController extends BaseController {

    @Autowired
    ITbXchTibDayService iTbXchTibDayService;

    @Autowired
    ITbTibHoursXchService iTbTibHoursXchService;

    @Autowired
    ITbTopFarmersService iTbTopFarmersService;

    @GetMapping
    public ResponseEntity<TbXchTibDay> get(){
        List<TbXchTibDay> tbXchTibDays = iTbXchTibDayService.list();
        if(tbXchTibDays.size() > 0){
            return ResponseEntity.ok(tbXchTibDays.get(0));
        }

        return ResponseEntity.ok(new TbXchTibDay());
    }

}
