package com.hl.chia.chiaweb.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class TbTopAddresses extends BaseEntity {

    private static final long serialVersionUID = 1L;


    private String address;

    private BigDecimal balance;

    private Integer rank;

    private Integer v;

    private LocalDateTime createTime;

}
