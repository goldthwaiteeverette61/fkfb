package com.hl.chia.chiaweb.dto;

import com.hl.chia.chiaweb.entity.TbBlockchainSummary;
import lombok.Data;

@Data
public class BlockchainSummaryResponse {

    private TbBlockchainSummary tbBlockchainSummary;
}
