package com.hl.chia.chiaweb.controller;


import com.hl.chia.chiaweb.entity.TbTopAddresses;
import com.hl.chia.chiaweb.service.ITbTopAddressesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@RestController
@RequestMapping("/top-addresses")
public class TbTopAddressesController extends BaseController {

    @Autowired
    ITbTopAddressesService iTbTopAddressesService;

    @GetMapping("list")
    public ResponseEntity<List<TbTopAddresses>> list(){
        return ResponseEntity.ok(iTbTopAddressesService.list());
    }
}
