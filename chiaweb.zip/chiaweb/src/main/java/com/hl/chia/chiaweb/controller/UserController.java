package com.hl.chia.chiaweb.controller;

import com.alibaba.fastjson.JSONObject;
import com.hl.chia.chiaweb.entity.User;
import com.hl.chia.chiaweb.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Wrapper;
import java.util.Random;

@RestController
@RequestMapping("/web/user")
public class UserController {
    @Autowired
    IUserService userService;

    @RequestMapping("/save")
    public String save(){
        User user2 = new User();
        for (int i = 0; i < 40; i++) {
            user2.setId((long)i);
            user2.setUserId((long)i);
            Random r = new Random();
            user2.setOrderId((long)r.nextInt(100));
            user2.setNickName("owenma"+i);
            user2.setPassWord("password"+i);
            user2.setUserName("userName"+i);
            userService.save(user2);
        }
        return "success";
    }

    @RequestMapping("/findAll")
    public String findAll(){
        return JSONObject.toJSONString(userService.lambdaQuery().list());
    }
}
