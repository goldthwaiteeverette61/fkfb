package com.hl.chia.chiaweb.dto;

import lombok.Data;

@Data
public class HttpResponseObj<T> extends BaseDto {

    T t;
}
