package com.hl.chia.chiaweb.scheduled;


import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.hl.chia.chiaweb.dto.*;
import com.hl.chia.chiaweb.entity.*;
import com.hl.chia.chiaweb.service.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class Collection {

    @Autowired
    ITbXchTibDayService iTbXchTibDayService;

    @Autowired
    ITbTibHoursXchService iTbTibHoursXchService;

    @Autowired
    ITbTopFarmersService iTbTopFarmersService;

    @Autowired
    ITbTopPoolsService iTbTopPoolsService;

    @Autowired
    ITbTopAddressesService iTbTopAddressesService;

    @Autowired
    ITbBlockchainSummaryService iTbBlockchainSummaryService;

    private static final String HOST = "https://api2.chiaexplorer.com";

    @Scheduled(fixedDelay = 1*60*1000)
    public void oneMin(){
        //xchTibDay
        HttpRequest httpRequest = new HttpRequest(HOST+"/chart/xchTibDay?period=2w");
        HttpResponse httpResponse = httpRequest.execute();
        XchTibDayResponse xchTibDayResponse = JSON.parseObject(httpResponse.body(), XchTibDayResponse.class);

        if(xchTibDayResponse != null && !StringUtils.isBlank(xchTibDayResponse.getData())) {
            //删除现有的
            LambdaQueryWrapper<TbXchTibDay> lq = Wrappers.lambdaQuery();
            iTbXchTibDayService.getBaseMapper().delete(lq.eq(TbXchTibDay::getD,1));
            TbXchTibDay tbXchTibDay = new TbXchTibDay();
            tbXchTibDay.setData(xchTibDayResponse.getData());
            tbXchTibDay.setTimestamp(xchTibDayResponse.getTimestamp());
            iTbXchTibDayService.save(tbXchTibDay);
        }else {
            log.info("================== 访问：chart/xchTibDay?period=2w 失败,xchTibDayResponse:"+JSON.toJSONString(xchTibDayResponse));
        }

        //TbTibHoursXch
        httpRequest = new HttpRequest(HOST+"/chart/tibHoursXch?period=2w");
        httpResponse = httpRequest.execute();
        xchTibDayResponse = JSON.parseObject(httpResponse.body(), XchTibDayResponse.class);

        if(xchTibDayResponse != null && !StringUtils.isBlank(xchTibDayResponse.getData())) {
            //删除现有的
            LambdaQueryWrapper<TbTibHoursXch> lq2 = Wrappers.lambdaQuery();
            iTbTibHoursXchService.getBaseMapper().delete(lq2.eq(TbTibHoursXch::getD,1));

            TbTibHoursXch tbTibHoursXch = new TbTibHoursXch();
            tbTibHoursXch.setData(xchTibDayResponse.getData());
            tbTibHoursXch.setTimestamp(xchTibDayResponse.getTimestamp());
            iTbTibHoursXchService.save(tbTibHoursXch);
        }else {
            log.info("================== 访问：chart/tibHoursXch?period=2w 失败,xchTibDayResponse:"+JSON.toJSONString(xchTibDayResponse));
        }


        //blockchainSummary
        httpRequest = new HttpRequest(HOST+"/blockchainSummary");
        httpResponse = httpRequest.execute();
        TbBlockchainSummary tbBlockchainSummary = JSON.parseObject(httpResponse.body(), TbBlockchainSummary.class);
        if(tbBlockchainSummary != null && !StringUtils.isBlank(tbBlockchainSummary.getNetspace())){
            //删除现有的
            LambdaQueryWrapper<TbBlockchainSummary> lq3 = Wrappers.lambdaQuery();
            iTbBlockchainSummaryService.getBaseMapper().delete(lq3.eq(TbBlockchainSummary::getD,1));
            iTbBlockchainSummaryService.save(tbBlockchainSummary);
        }else {
            log.info("================== 访问：blockchainSummary 失败,tbBlockchainSummary:"+JSON.toJSONString(tbBlockchainSummary));
        }

    }

    @Scheduled(fixedDelay = 5*60*1000)
    public void fiveMin(){
        //topFarmers
        HttpRequest httpRequest = new HttpRequest(HOST+"/topFarmers");
        HttpResponse httpResponse = httpRequest.execute();
        TopFarmersResponse topFarmersResponse = JSON.parseObject(httpResponse.body(), TopFarmersResponse.class);
        if(topFarmersResponse != null && topFarmersResponse.getTopFarmers() != null && topFarmersResponse.getTopFarmers().size() > 0){
            //删除现有的
            LambdaQueryWrapper<TbTopFarmers> lq2 = Wrappers.lambdaQuery();
            iTbTopFarmersService.getBaseMapper().delete(lq2.eq(TbTopFarmers::getD,1));
            for (TbTopFarmers tbTopFarmers:topFarmersResponse.getTopFarmers()) {
                iTbTopFarmersService.save(tbTopFarmers);
            }
        }

        //topPools
        httpRequest = new HttpRequest(HOST+"/topPools?filter=10k");
        httpResponse = httpRequest.execute();
        TopPoolsResponse topPoolsResponse = JSON.parseObject(httpResponse.body(), TopPoolsResponse.class);
        if(topPoolsResponse != null && topPoolsResponse.getTopPools() != null && topPoolsResponse.getTopPools().size() > 0){
            //删除现有的
            LambdaQueryWrapper<TbTopPools> lq3 = Wrappers.lambdaQuery();
            iTbTopPoolsService.getBaseMapper().delete(lq3.eq(TbTopPools::getD,1));
            for (TbTopPools tbTopPools:topPoolsResponse.getTopPools()) {
                iTbTopPoolsService.save(tbTopPools);
            }
        }else{
            log.info("================== 访问：topPools?filter=10k 失败,topPoolsResponse:"+JSON.toJSONString(topPoolsResponse));
        }

        //topAddresses
        httpRequest = new HttpRequest(HOST+"/topAddresses");
        httpResponse = httpRequest.execute();
        TopAddressResponse topAddressResponse = JSON.parseObject(httpResponse.body(), TopAddressResponse.class);
        if(topAddressResponse != null && topAddressResponse.getTopAddresses() != null && topAddressResponse.getTopAddresses().size() > 0){
            //删除现有的
            LambdaQueryWrapper<TbTopAddresses> lq4 = Wrappers.lambdaQuery();
            iTbTopAddressesService.getBaseMapper().delete(lq4.eq(TbTopAddresses::getD,1));
            for (TbTopAddresses tbTopAddresses:topAddressResponse.getTopAddresses()) {
                iTbTopAddressesService.save(tbTopAddresses);
            }
        }else{
            log.info("================== 访问：topAddresses 失败,topAddressResponse:"+JSON.toJSONString(topAddressResponse));
        }

    }

}
