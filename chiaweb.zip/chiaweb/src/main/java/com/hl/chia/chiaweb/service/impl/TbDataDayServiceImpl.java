package com.hl.chia.chiaweb.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hl.chia.chiaweb.entity.TbDataDay;
import com.hl.chia.chiaweb.mapper.TbDataDayMapper;
import com.hl.chia.chiaweb.service.ITbDataDayService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 日期数据 服务实现类
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Service
public class TbDataDayServiceImpl extends ServiceImpl<TbDataDayMapper, TbDataDay> implements ITbDataDayService {

}
