package com.hl.chia.chiaweb.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hl.chia.chiaweb.entity.TbTibHoursXch;
import com.hl.chia.chiaweb.mapper.TbTibHoursXchMapper;
import com.hl.chia.chiaweb.service.ITbTibHoursXchService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author clx
 * @since 2021-04-19
 */
@Service
public class TbTibHoursXchServiceImpl extends ServiceImpl<TbTibHoursXchMapper, TbTibHoursXch> implements ITbTibHoursXchService {

}
